import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';


class ApiService {
  static const String baseUrl = 'http://localhost:3000';

  // Enregistrer un nouvel utilisateur
  static Future<bool> register(String name, String email, String password,  String address, String phone) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "name": name,
        "email": email,
        "password": password,
        "address": address,
        "phone": phone,
      }),
    );

    return response.statusCode == 201;
  }


  // Méthode pour la connexion
  static Future<bool> login(String email, String password) async {
    final url = Uri.parse('$baseUrl/login');
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": email,
          "password": password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['token'] != null) {
          // Sauvegarder le token dans shared_preferences
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('token', data['token']);
          print("Token sauvegardé : ${data['token']}");
          return true;
        }
      } else {
        print("Erreur ${response.statusCode}: ${response.body}");
      }
    } catch (e) {
      print("Erreur lors de la connexion : $e");
    }
    return false;
  }

  static Future<List<dynamic>> getCategories() async {
    final response = await http.get(Uri.parse('$baseUrl/categories'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  }

  static Future<List<dynamic>> getProducts() async {
    final response = await http.get(Uri.parse('$baseUrl/products'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  }

  // Méthode pour récupérer le token
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // Obtenir le profil utilisateur
  static Future<Map<String, dynamic>> getUserProfile() async {
    try {
      final token = await getToken();
      if (token == null) {
        throw Exception("Aucun token trouvé, utilisateur non connecté");
      }

      print("Tentative avec token : $token");

      final response = await http.get(
        Uri.parse('$baseUrl/profile'),
        headers: {"Authorization": "Bearer $token"},
      );

      print("Statut HTTP : ${response.statusCode}");
      print("Réponse brute : ${response.body}");

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception("Erreur HTTP ${response.statusCode}");
      }
    } catch (e) {
      print('Erreur dans la requête utilisateur : $e');
      throw e;
    }
  }



  // Obtenir l'historique des commandes
  static Future<List<dynamic>> getUserOrders() async {
    try {
      final token = await getToken();
      if (token == null) {
        throw Exception("Aucun token trouvé, utilisateur non connecté");
      }

      final response = await http.get(
        Uri.parse('$baseUrl/orders'),
        headers: {"Authorization": "Bearer $token"},
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception("Impossible de récupérer l'historique des commandes");
      }
    } catch (e) {
      print('Erreur dans la récupération des commandes : $e');
      throw e;
    }
  }
}
