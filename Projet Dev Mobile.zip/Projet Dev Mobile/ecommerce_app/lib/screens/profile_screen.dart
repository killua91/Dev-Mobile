import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ecommerce_app/widgets/bottom_navbar.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic> userData = {};
  List<dynamic> orderHistory = [];
  List<dynamic> cartItems = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserData();
    loadCartItems();
  }

  Future<void> fetchUserData() async {
    try {
      print("Tentative de récupération des données utilisateur...");

      final userProfile = await ApiService.getUserProfile();
      print("Données utilisateur récupérées : $userProfile");

      final userOrders = await ApiService.getUserOrders();
      print("Historique des commandes récupérées : $userOrders");

      setState(() {
        userData = userProfile;
        orderHistory = userOrders;
        isLoading = false;
      });
    } catch (e) {
      print('Erreur lors de la récupération des données : $e');
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Une erreur est survenue lors de la récupération des données."),
      ));
    }
  }

  // Simuler la récupération des données du panier
  Future<void> loadCartItems() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cartData = prefs.getStringList('cart_items') ?? [];
      setState(() {
        cartItems = cartData;
      });
    } catch (e) {
      print("Erreur lors du chargement des éléments du panier : $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Profil"),
        backgroundColor: Colors.red[900],
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 4,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.red[900]!, Colors.red[900]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Informations personnelles
            _buildSectionTitle("Informations Personnelles"),
            _buildInfoRow("Nom complet", userData['nom'] ?? 'Non défini'),
            _buildInfoRow("Adresse email", userData['email'] ?? 'Non défini'),
            _buildInfoRow("Numéro de téléphone", userData['téléphone']?.toString() ?? 'Non défini'),
            Divider(),

            // Historique des commandes
            _buildSectionTitle("Historique des commandes"),
            orderHistory.isEmpty
                ? Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                "Vous n'avez passé aucune commande pour le moment.",
                style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
            )
                : Column(
              children: orderHistory.map((order) => _buildOrderTile(
                order['id'].toString(),
                order['statut'] ?? 'Statut inconnu',
              )).toList(),
            ),

            Divider(),

            // Déconnexion
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.red[900],
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 4,
                ),
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  Navigator.pushReplacementNamed(context, '/login');
                },
                child: Text("Déconnexion"),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        cartCount: cartItems.length,
        currentIndex: 2,
      ),
    );
  }

  Widget _buildInfoRow(String title, dynamic value) {
    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.96,
        child: Card(
          elevation: 3,
          color: Colors.grey[300],
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: ListTile(
            leading: Icon(Icons.info, color: Colors.red[900]),
            title: Text(title),
            subtitle: Text(value != null ? value.toString() : 'Non défini'),
          ),
        ),
      ),
    );
  }


  Widget _buildOrderTile(String orderNumber, String status) {
    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.92,
        child: Card(
          elevation: 3,
          color: Colors.grey[300],
          child: ListTile(
            leading: Icon(Icons.shopping_bag, color: Colors.red[900]),
            title: Text(
              "Commande n°$orderNumber",
              style: TextStyle(color: Colors.black),
            ),
            subtitle: Text(
              "Statut : $status",
              style: TextStyle(color: Colors.black54),
            ),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text("Détails de la commande n°$orderNumber"),
              ));
            },
          ),
        ),
      ),
    );
  }



  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, left: 20, bottom: 10),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          title,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
