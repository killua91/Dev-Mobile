import 'package:flutter/material.dart';
import 'package:ecommerce_app/screens/cart_screen.dart';
import 'package:ecommerce_app/screens/profile_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'home_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  final Function addToCart;

  ProductDetailScreen({required this.product, required this.addToCart});

  @override
  _ProductDetailScreenState createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int cartCount = 0;

  @override
  void initState() {
    super.initState();
    loadCartCount();
  }

  // Récupérer le nombre d'articles dans le panier depuis SharedPreferences
  Future<void> loadCartCount() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> cart = prefs.getStringList('cart') ?? [];
    setState(() {
      cartCount = cart.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.product.name,
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.red[900],
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          Image.network(widget.product.image),
          SizedBox(height: 10),
          Text(widget.product.name, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          Text("${widget.product.price} \MAD", style: TextStyle(fontSize: 18, color: Colors.green)),
          SizedBox(height: 10),
          Text(widget.product.description, style: TextStyle(fontSize: 16)),
          Spacer(),
          ElevatedButton(
            onPressed: () => widget.addToCart(widget.product),
            child: Text("Ajouter au panier"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[900],
              foregroundColor: Colors.white,
            ),
          ),
          SizedBox(height: 10),
          _buildBottomNavBar(),
        ],
      ),
    );
  }

  /// 📦 Bottom Navigation Bar
  Widget _buildBottomNavBar() {
    return Container(
      color: Colors.grey[200],
      height: 60,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.home),
            color: Colors.red[900],
          ),
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartScreen()),
              );
            },
            icon: Stack(
              children: [
                Icon(Icons.shopping_cart, color: Colors.red[900]),
                if (cartCount > 0)
                  Positioned(
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '$cartCount',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
            icon: Icon(Icons.account_circle),
            color: Colors.red[900],
          ),
        ],
      ),
    );
  }
}
