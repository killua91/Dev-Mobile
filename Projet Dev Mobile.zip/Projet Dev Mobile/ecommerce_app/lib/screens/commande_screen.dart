import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ecommerce_app/services/api_service.dart';
import 'package:ecommerce_app/widgets/bottom_navbar.dart';
import 'home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';


final List<Map<String, dynamic>> transporteurs = [
  {"nom": "DHL", "frais": 10.0},
  {"nom": "UPS", "frais": 15.0},
  {"nom": "La Poste", "frais": 5.0}
];
String? selectedTransporteur;

class CommandeScreen extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems;

  const CommandeScreen({Key? key, required this.cartItems}) : super(key: key);

  @override
  _CommandeScreenState createState() => _CommandeScreenState();
}

class _CommandeScreenState extends State<CommandeScreen> {
  final _formKey = GlobalKey<FormState>();
  String nom = '';
  String prenom = '';
  String adresse = '';
  String ville = '';
  String pays = 'Maroc';
  String transporteur = '';
  double fraisLivraison = 0.0;
  String modePaiement = 'Espèces';
  bool showCardInputs = false;

  void clearCartSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('cart');
    setState(() {
      widget.cartItems.clear();
    });
  }

  Future<void> submitCommande() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      if (widget.cartItems.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Votre panier est vide."),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
        return;
      }

      try {
        print("Panier avant soumission : ${widget.cartItems}");

        final token = await ApiService.getToken();
        if (token == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("Vous devez d'abord vous connecter."),
              backgroundColor: Colors.red,
              duration: Duration(seconds: 2),
            ),
          );
          return;
        }

        final response = await http.post(
          Uri.parse('http://localhost:3000/commande'),
          headers: {
            "Authorization": "Bearer $token",
            "Content-Type": "application/json",
          },
          body: jsonEncode({
            "adresse_livraison": adresse,
            "transporteur": transporteur,
            "mode_paiement": modePaiement,
            "frais_livraison": fraisLivraison,
            "produits": widget.cartItems.map((item) => {
              "id": int.tryParse(item['id'].toString()) ?? 0,
              "quantite": item['quantity'],
              "prix_unitaire": item['price']
            }).toList(),
          }),
        );

        print('Statut HTTP : ${response.statusCode}');
        print('Réponse : ${response.body}');

        if (response.statusCode == 201) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("Commande réussie !"),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
          // Vider le panier après la soumission
          clearCartSession();

          // Rediriger vers la page d'accueil
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
                (Route<dynamic> route) => false,
          );
        } else {
          throw Exception('Échec de la commande');
        }
      } catch (e) {
        print('Erreur : $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Erreur lors de la soumission : $e"),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Commande"),
        backgroundColor: Colors.red[900],
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      bottomNavigationBar: CustomBottomNavBar(
        cartCount: widget.cartItems.length,
        currentIndex: 1,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    "Informations de livraison",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  _buildTextField(
                    labelText: "Nom",
                    icon: Icons.person,
                    onChanged: (value) => nom = value,
                  ),
                  const SizedBox(height: 10),
                  _buildTextField(
                    labelText: "Prénom",
                    icon: Icons.person,
                    onChanged: (value) => prenom = value,
                  ),
                  const SizedBox(height: 10),
                  _buildTextField(
                    labelText: "Adresse",
                    icon: Icons.location_on,
                    onChanged: (value) => adresse = value,
                  ),
                  const SizedBox(height: 10),
                  _buildTextField(
                    labelText: "Ville",
                    icon: Icons.location_city,
                    onChanged: (value) => ville = value,
                  ),
                  const SizedBox(height: 10),
                  _buildTextField(
                    labelText: "Pays",
                    icon: Icons.public,
                    onChanged: null, // Pays fixe
                    initialValue: "Maroc",
                    readOnly: true,
                  ),
                  const SizedBox(height: 20),
                  DropdownButtonFormField<String>(
                    value: selectedTransporteur,
                    decoration: InputDecoration(
                      labelText: 'Transporteur de livraison',
                      labelStyle: TextStyle(color: Colors.black),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.red[900]!, width: 3),
                      ),
                    ),
                    items: transporteurs
                        .map(
                          (t) => DropdownMenuItem<String>(
                        value: t['nom'].toString(),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(t['nom']),
                            Text(
                              ' ${t['frais']} DH',
                              style: TextStyle(color: Colors.grey[700]),
                            ),
                          ],
                        ),
                      ),
                    )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedTransporteur = value;
                        transporteur = value ?? '';
                        fraisLivraison = transporteurs.firstWhere(
                              (element) => element['nom'] == value,
                        )['frais'];
                      });
                    },
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: ElevatedButton(
                      onPressed: submitCommande,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red[900],
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text(
                        "Passer la commande",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String labelText,
    required IconData icon,
    required Function(String)? onChanged,
    String? initialValue,
    bool readOnly = false,
  }) {
    return TextField(
      style: const TextStyle(color: Colors.black),
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: const TextStyle(color: Colors.black),
        prefixIcon: Icon(icon, color: Colors.black),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.red[900]!, width: 3),
        ),
      ),
      onChanged: onChanged,
      readOnly: readOnly,
      controller: initialValue != null ? TextEditingController(text: initialValue) : null,
    );
  }
}
