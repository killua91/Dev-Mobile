import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../widgets/bottom_navbar.dart';
import 'package:ecommerce_app/screens/commande_screen.dart';

class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List<dynamic> cartItems = [];

  @override
  void initState() {
    super.initState();
    loadCartItems();
  }

  /// 🔄 Charger les produits du panier depuis SharedPreferences
  Future<void> loadCartItems() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> cartData = prefs.getStringList('cart') ?? [];
    setState(() {
      cartItems = cartData.map((item) => jsonDecode(item)).toList();
    });
  }

  /// 🗑️ Supprimer un produit du panier
  void removeItemFromCart(int index) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> cartData = prefs.getStringList('cart') ?? [];
    cartData.removeAt(index);
    await prefs.setStringList('cart', cartData);

    setState(() {
      cartItems.removeAt(index);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.white),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                "Produit supprimé du panier",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.red[700],
        duration: Duration(seconds: 1),
      ),
    );
  }

  /// 🧮 Calculer le prix total
  double calculateTotalPrice() {
    double total = 0.0;
    for (var item in cartItems) {
      total += item['price'] * item['quantity'];
    }
    return total;
  }

  /// ➕ Augmenter la quantité d'un produit
  void increaseQuantity(int index) {
    setState(() {
      cartItems[index]['quantity'] += 1;
    });
    updateCartInSession();
  }

  /// ➖ Diminuer la quantité d'un produit
  void decreaseQuantity(int index) {
    if (cartItems[index]['quantity'] > 1) {
      setState(() {
        cartItems[index]['quantity'] -= 1;
      });
      updateCartInSession();
    }
  }

  /// 💾 Mettre à jour le panier dans SharedPreferences
  Future<void> updateCartInSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> updatedCart = cartItems.map((item) => jsonEncode(item)).toList();
    await prefs.setStringList('cart', updatedCart);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Panier"),
        backgroundColor: Colors.red[900],
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: cartItems.isEmpty
          ? Center(
        child: Text(
          "Votre panier est vide.",
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      )
          : Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                var item = cartItems[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: ListTile(
                    leading: Image.network(
                      item['image'],
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(Icons.image, color: Colors.grey);
                      },
                    ),
                    title: Text(
                      item['name'],
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text("\$${item['price']}"),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.remove, color: Colors.red),
                          onPressed: () => decreaseQuantity(index),
                        ),
                        Text(
                          item['quantity'].toString(),
                          style: TextStyle(fontSize: 16),
                        ),
                        IconButton(
                          icon: Icon(Icons.add, color: Colors.green),
                          onPressed: () => increaseQuantity(index),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => removeItemFromCart(index),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20, left: 10, bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Prix Total
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Text(
                    "Prix Total : \$${calculateTotalPrice().toStringAsFixed(2)}",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),

                // Bouton Commander
                Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CommandeScreen(
                            cartItems: List<Map<String, dynamic>>.from(cartItems),
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red[900],
                      foregroundColor: Colors.white,
                    ),
                    child: Text("Commander"),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(
        cartCount: cartItems.length,
        currentIndex: 1,
      ),
    );
  }
}


