import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ecommerce_app/screens/cart_screen.dart';
import 'package:ecommerce_app/screens/profile_screen.dart';
import 'product_details_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Product> products = [];
  List<Category> categories = [];
  String token = "";
  int cartCount = 0;
  int? selectedCategoryId;


  @override
  void initState() {
    super.initState();
    getToken();
    fetchCategories();
    loadCartCount();
  }

  /// 🔑 Récupération du token
  Future<void> getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      token = prefs.getString('token') ?? "";
    });
    if (token.isEmpty) {
      print("Token est vide ou non configuré.");
    } else {
      fetchProducts();
    }
  }

  /// 🌐 Appel API pour récupérer les produits
  Future<void> fetchProducts({int? categoryId}) async {
    try {
      String url = 'http://localhost:3000/products';
      if (categoryId != null) {
        url += '?categoryId=$categoryId';
      }

      print("URL de la requête : $url");

      final response = await http.get(
        Uri.parse(url),
        headers: {"Authorization": "Bearer $token"},
      );

      print("Statut de la réponse : ${response.statusCode}");
      print("Réponse brute : ${response.body}");

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        print("Données récupérées : $data");

        setState(() {
          products = data.map((item) => Product.fromJson(item)).toList();
        });

        print("Produits après mappage : $products");
      } else {
        print("Échec de la récupération des données. Statut : ${response.statusCode}");
      }
    } catch (e) {
      print('Erreur lors de la récupération des produits : $e');
    }
  }



  /// 🌐 Appel API pour récupérer les catégories
  Future<void> fetchCategories() async {
    try {
      final response = await http.get(Uri.parse('http://localhost:3000/categories'));

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          categories = data.map((item) => Category.fromJson(item)).toList();
        });
      }
    } catch (e) {
      print('Erreur lors de la récupération des catégories : $e');
    }
  }

  /// 🛒 Ajouter au panier
  void addToCart(Product product) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> cart = prefs.getStringList('cart') ?? [];

    // Ajouter le produit sous forme JSON
    cart.add(jsonEncode({
      'id': product.id,
      'name': product.name,
      'price': product.price,
      'image': product.image,
      'quantity': 1
    }));

    await prefs.setStringList('cart', cart);

    setState(() {
      cartCount = cart.length;
    });

    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  "Ajouté au panier: ${product.name}",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          backgroundColor: Colors.green,
          duration: Duration(milliseconds: 150),
        ),
    );
  }

  Future<void> loadCartCount() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> cart = prefs.getStringList('cart') ?? [];
    setState(() {
      cartCount = cart.length;
    });
  }

  void clearCartSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('cart');
    setState(() {
      cartCount = 0;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          _buildAppBar(),
          _buildCategorySlider(),
          Expanded(child: _buildProductGrid()),
          _buildBottomNavBar(),
        ],
      ),
    );
  }

  /// 📌 Titre de l'application
  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: Image.asset(
          'assets/logo.png',
          height: 130,
        ),
      ),
    );
  }

  /// 🌊 Slider horizontal avec les catégories (style modernisé)
  Widget _buildCategorySlider() {
    return Container(
      height: 60,
      padding: EdgeInsets.symmetric(vertical: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length + 1, // Inclure la catégorie "Tous"
        itemBuilder: (context, index) {
          if (index == 0) {
            return _buildCategoryText(
                Category(id: -1, name: "Tous", description: ""),
                index
            );
          }
          return _buildCategoryText(
            categories[index - 1],
            index,
          );
        },
      ),
    );
  }


  /// 🏷️ Texte moderne pour chaque catégorie
  Widget _buildCategoryText(Category category, int index) {
    bool isSelected = selectedCategoryId == (category.id == -1 ? null : category.id);

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedCategoryId = category.id == -1 ? null : category.id;
          print("Selected Category ID: $selectedCategoryId");
          fetchProducts(categoryId: selectedCategoryId);
        });
      },

      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 15),
        padding: const EdgeInsets.only(bottom: 2),
        decoration: BoxDecoration(
          border: isSelected
              ? Border(
            bottom: BorderSide(
              color: Colors.red[900]!,
              width: 2,
            ),
          )
              : null,
        ),
        child: Text(
          category.name,
          style: TextStyle(
            fontFamily: 'Roboto',
            fontSize: 14,
            fontWeight: FontWeight.w900,
            color: isSelected ? Colors.red[900] : Colors.black,
          ),
        ),
      ),

    );
  }



  /// 📦 Grille avec les produits
  Widget _buildProductGrid() {
    return products.isEmpty
        ? Center(child: CircularProgressIndicator())
        : GridView.builder(
      padding: EdgeInsets.all(8),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1,
        crossAxisSpacing: 20,
        mainAxisSpacing: 12,
      ),
      itemCount: products.length,
      itemBuilder: (context, index) {
        return _buildProductCard(products[index]);
      },
    );
  }

  /// 🛒 Carte produit avec image, nom, prix, bouton
  Widget _buildProductCard(Product product) {
    return GestureDetector(
      onTap: () {
        // When navigating to the ProductDetailScreen, pass the addToCart function
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(
              product: product,
              addToCart: addToCart, // Pass the addToCart function
            ),
          ),
        );
      },
      child: Card(
        elevation: 4,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Afficher l'image depuis une URL avec une taille fixe
            Container(
              height: 130,
              width: double.infinity,
              child: Image.network(
                product.image,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 8),
            // Nom du produit
            Text(
              product.name,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 4),
            // Prix
            Text(
              "${product.price} \MAD",
              style: TextStyle(color: Colors.green, fontSize: 14),
            ),
            SizedBox(height: 4),
            // Bouton Ajouter au panier
            ElevatedButton(
              onPressed: () => addToCart(product),
              child: Text("Ajouter"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[900],
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                minimumSize: Size(MediaQuery.of(context).size.width * 0.3, 40),
              ),
            ),
          ],
        ),
      ),
    );
  }






  /// 🔗 Barre de navigation en bas
  Widget _buildBottomNavBar() {
    return Container(
      color: Colors.grey[200],
      height: 60,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.home),
            color: Colors.red[900],
          ),
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartScreen()),
              );
            },
            icon: Stack(
              children: [
                Icon(Icons.shopping_cart, color: Colors.red[900]),
                if (cartCount > 0)
                  Positioned(
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '$cartCount',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
            icon: Icon(Icons.account_circle),
            color: Colors.red[900],
          ),
        ],
      ),
    );
  }
}

/// 📦 Structure pour représenter un produit
class Product {
  final String id;
  final String name;
  final String image;
  final double price;
  final String description;

  Product({
    required this.id,
    required this.name,
    required this.image,
    required this.price,
    required this.description,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'].toString(),
      name: json['nom'] ?? "Inconnu",
      image: json['image'] ?? '',
      price: double.tryParse(json['prix'].toString()) ?? 0.0,
      description: json['description'] ?? "Aucune description disponible",
    );
  }
}

/// 📦 Structure pour représenter une catégorie
class Category {
  final int id;
  final String name;
  final String description;

  Category({
    required this.id,
    required this.name,
    required this.description,
  });

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      id: json['id'],
      name: json['nom'] ?? "Inconnu",
      description: json['description'] ?? '',
    );
  }
}