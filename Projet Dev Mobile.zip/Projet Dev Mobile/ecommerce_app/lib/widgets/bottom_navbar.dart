import 'package:flutter/material.dart';

class CustomBottomNavBar extends StatelessWidget {
  final int cartCount;
  final int currentIndex;

  const CustomBottomNavBar({
    Key? key,
    required this.cartCount,
    required this.currentIndex,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[200],
      height: 60,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/home'); // Navigue vers HomeScreen
            },
            icon: Icon(Icons.home),
            color: Colors.red[900],
          ),
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/cart'); // Navigue vers CartScreen
            },
            icon: Stack(
              children: [
                Icon(Icons.shopping_cart,
                    color: Colors.red[900]),
                if (cartCount > 0) // Badge uniquement si le panier n'est pas vide
                  Positioned(
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '$cartCount',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/profile'); // Navigue vers ProfileScreen
            },
            icon: Icon(Icons.account_circle),
            color: Colors.red[900],
          ),
        ],
      ),
    );
  }
}
