const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const session = require('express-session');
const db = require('./db');

const app = express();
const SECRET_KEY = 'your_secret_key';
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Configuration des sessions
app.use(
  session({
    secret: 'your_secret_key', 
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, 
  })
);

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Token manquant ou invalide' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Token invalide', error: err.message });
  }
};

app.post('/protected', (req, res) => {
  const token = req.body.token; 

  if (!token) {
    return res.status(401).json({ message: 'Token manquant dans le body' });
  }

  try {
    const decoded = jwt.verify(token, 'votre_secret'); 
    res.status(200).json({ message: 'Token valide', data: decoded });
  } catch (error) {
    res.status(401).json({ message: 'Token invalide', error: error.message });
  }
});


// Route pour l'inscription
app.post('/register', async (req, res) => {
  const { name, email, password,  address, phone} = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = 'INSERT INTO Utilisateur (nom, email, mot_de_passe, adresse, téléphone, rôle) VALUES (?, ?, ?, ?, ?, ?)';

    db.query(query, [name, email, hashedPassword, address, phone,'client'], (error, results) => {
      if (error) {
        return res.status(400).json({ message: 'Erreur lors de l\'inscription' });
      }
      res.status(201).json({ message: 'Compte créé avec succès' });
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// Route pour la connexion
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const query = 'SELECT * FROM Utilisateur WHERE email = ?';
  db.query(query, [email], async (error, results) => {
    if (error) {
      return res.status(500).json({ message: 'Erreur de connexion' });
    }

    if (results.length) {
      const isPasswordValid = await bcrypt.compare(password, results[0].mot_de_passe);

      if (isPasswordValid) {
        // Générer le token JWT
        const token = jwt.sign(
          { id: results[0].id, role: results[0].rôle },
          SECRET_KEY,
          { expiresIn: '4h' }
        );

        // Définir la session utilisateur
        req.session.user = { id: results[0].id, role: results[0].rôle };

        return res.status(200).json({
          token,
          user: {
            id: results[0].id,
            email: results[0].email,
            role: results[0].rôle,
          },
          message: 'Connexion réussie',
        });
      } else {
        return res.status(401).json({ message: 'Identifiants incorrects' });
      }
    } else {
      return res.status(401).json({ message: 'Identifiants incorrects' });
    }
  });
});

// Route pour récupérer les catégories
app.get('/categories', (req, res) => {
  const query = 'SELECT * FROM Categorie';
  db.query(query, (error, results) => {
    if (error) {
      return res.status(500).json({ message: 'Erreur lors de la récupération des catégories' });
    }
    res.status(200).json(results);
  });
});

// Route pour récupérer les produits
app.get('/products', (req, res) => {
  const { categoryId } = req.query;
  let query = 'SELECT * FROM Produit';
  const queryParams = [];

  if (categoryId) {
    query += ' WHERE id_categorie = ?';
    queryParams.push(categoryId);
  }

  db.query(query, queryParams, (error, results) => {
    if (error) {
      console.error('Erreur SQL :', error); 
      return res.status(500).json({ message: 'Erreur lors de la récupération des produits' });
    }
    res.status(200).json(results);
  });
});



// Route pour ajouter un produit au panier dans la session
app.post('/add-to-cart', (req, res) => {
  const { productId } = req.body;

  if (!req.session.cart) {
    req.session.cart = [];
  }

  req.session.cart.push(productId);

  res.status(200).json({ message: 'Produit ajouté au panier', cart: req.session.cart });
});

// Route pour récupérer les infos utilisateur

app.get('/profile', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1]; // Récupère le token Bearer

  if (!token) {
    return res.status(401).json({ message: 'Vous n\'êtes pas connecté' });
  }

  // Vérifie le token avec la clé secrète
  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
      console.error(err);
      return res.status(401).json({ message: 'Token invalide ou expiré' });
    }

    const userId = decoded.id; // Utilisateur décodé à partir du token

    const query = 'SELECT * FROM Utilisateur WHERE id = ?';
    db.query(query, [userId], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Erreur serveur' });
      }

      if (results.length) {
        res.status(200).json(results[0]);
      } else {
        res.status(404).json({ message: 'Utilisateur non trouvé' });
      }
    });
  });
});


app.get('/orders', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Vous n\'êtes pas connecté' });
  }

  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Token invalide ou expiré' });
    }

    const userId = decoded.id;

    const query = 'SELECT * FROM commande WHERE id_utilisateur = ?';
    db.query(query, [userId], (error, results) => {
      if (error) {
        console.error('Erreur dans la requête SQL :', error);
        return res.status(500).json({ message: 'Erreur serveur' });
      }

      if (results.length) {
        res.status(200).json(results);
      } else {
        res.status(404).json({ message: 'Aucune commande trouvée' });
      }
    });
  });
});

// Route pour créer une commande
app.post('/commande', authMiddleware, async (req, res) => {
  const { adresse_livraison, transporteur, mode_paiement = 'par défaut', frais_livraison, produits } = req.body;

  if (!produits || produits.length === 0) {
    return res.status(400).json({ message: 'Aucun produit sélectionné pour la commande' });
  }

  try {
    const montant_total = produits.reduce((total, p) => {
      const prixUnitaire = p.prix_unitaire * p.quantite;
      return total + prixUnitaire;
    }, 0) + frais_livraison;

    const dateEstimeeLivraison = new Date();
    dateEstimeeLivraison.setDate(dateEstimeeLivraison.getDate() + 7);
    const dateEstimeeLivraisonStr = dateEstimeeLivraison.toISOString().split('T')[0]; 

    const commandeResult = await new Promise((resolve, reject) => {
      db.query(
        'INSERT INTO Commande (id_utilisateur, date_commande, montant_total, statut) VALUES (?, NOW(), ?, "en attente")',
        [req.user.id, montant_total],
        (err, results) => {
          if (err) reject(err);
          else resolve(results);
        }
      );
    });

    const commandeId = commandeResult.insertId;

    for (const produit of produits) {
      await new Promise((resolve, reject) => {
        db.query(
          'UPDATE Produit SET stock = stock - ? WHERE id = ? AND stock >= ?',
          [produit.quantite, produit.id, produit.quantite],
          (err, results) => {
            if (err) reject(err);
            else if (results.affectedRows === 0) reject(new Error('Stock insuffisant ou produit introuvable'));
            else resolve();
          }
        );
      });
    }

    const productQueries = produits.map((p) => {
      return new Promise((resolve, reject) => {
        db.query(
          'INSERT INTO DetailCommande (id_commande, id_produit, quantité, prix_unitaire) VALUES (?, ?, ?, ?)',
          [commandeId, p.id, p.quantite, p.prix_unitaire * p.quantite],
          (error) => {
            if (error) reject(error);
            else resolve();
          }
        );
      });
    });

    const factureQuery = new Promise((resolve, reject) => {
      db.query(
        'INSERT INTO Facture (id_commande, montant, mode_paiement) VALUES (?, ?, "espece")',
        [commandeId, montant_total],
        (error) => {
          if (error) reject(error);
          else resolve();
        }
      );
    });

    const livraisonQuery = new Promise((resolve, reject) => {
      db.query(
        'INSERT INTO Livraison (id_commande, adresse_livraison, transporteur, frais_livraison, date_estimee) VALUES (?, ?, ?, ?, ?)',
        [commandeId, adresse_livraison, transporteur, frais_livraison, dateEstimeeLivraisonStr],
        (error) => {
          if (error) reject(error);
          else resolve();
        }
      );
    });

    await Promise.all([...productQueries, factureQuery, livraisonQuery]);

    res.status(201).json({ message: 'Commande créée avec succès', commandeId });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la création de la commande', error: error.message });
  }
});







app.listen(port, () => {
  console.log(`Serveur démarré sur http://localhost:${port}`);
});


