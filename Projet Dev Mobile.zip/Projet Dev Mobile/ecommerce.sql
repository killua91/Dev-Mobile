-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 19 déc. 2024 à 10:49
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ecommerce`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`, `description`) VALUES
(1, 'Consoles', 'Consoles de jeux vidéo'),
(2, 'Jeux Vidéo', 'Jeux vidéo pour toutes les plateformes'),
(3, 'Accessoires', 'Accessoires pour gaming'),
(4, 'PC Gaming', 'Composants et accessoires pour PC gaming'),
(5, 'Streaming et VR', 'Équipements dédiés au streaming et à la réalité virtuelle, comprenant des caméras, microphones, casques VR et autres accessoires pour améliorer vos sessions de jeu en direct ou d\'immersion.'),
(6, 'Merchandising Gaming', 'Produits dérivés officiels des jeux vidéo populaires : t-shirts, posters, figurines, et autres objets de collection pour les fans de jeux vidéo.'),
(7, 'Jeux mobiles', 'Jeux mobiles pour smartphones et tablettes. Découvrez une large gamme de jeux populaires, allant des puzzles et jeux de stratégie aux jeux de rôle et d\'action sur mobile.');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id` int(11) NOT NULL,
  `id_utilisateur` int(11) NOT NULL,
  `date_commande` datetime DEFAULT current_timestamp(),
  `montant_total` decimal(10,2) NOT NULL,
  `statut` enum('en attente','payée','livrée') DEFAULT 'en attente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id`, `id_utilisateur`, `date_commande`, `montant_total`, `statut`) VALUES
(1, 1, '2024-12-01 10:00:00', 539.99, 'payée'),
(2, 1, '2024-12-05 15:30:00', 1199.97, 'livrée'),
(3, 1, '2024-12-10 18:45:00', 259.98, 'en attente'),
(4, 1, '2024-12-19 09:51:37', 54.99, 'en attente'),
(5, 2, '2024-12-19 10:21:49', 514.99, 'en attente');

-- --------------------------------------------------------

--
-- Structure de la table `detailcommande`
--

CREATE TABLE `detailcommande` (
  `id` int(11) NOT NULL,
  `id_commande` int(11) NOT NULL,
  `id_produit` int(11) NOT NULL,
  `quantité` int(11) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `detailcommande`
--

INSERT INTO `detailcommande` (`id`, `id_commande`, `id_produit`, `quantité`, `prix_unitaire`) VALUES
(1, 1, 1, 1, 499.99),
(2, 1, 2, 1, 39.99),
(3, 2, 3, 1, 499.99),
(4, 2, 4, 2, 59.99),
(5, 2, 6, 1, 49.99),
(6, 3, 5, 1, 89.99),
(7, 3, 7, 2, 129.99),
(8, 4, 4, 1, 39.99),
(9, 5, 2, 1, 499.99);

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `id` int(11) NOT NULL,
  `id_commande` int(11) NOT NULL,
  `date_facture` datetime DEFAULT current_timestamp(),
  `montant` decimal(10,2) NOT NULL,
  `mode_paiement` enum('CB','especes') DEFAULT 'especes',
  `statut_paiement` enum('en attente','payé','annulé') DEFAULT 'en attente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `facture`
--

INSERT INTO `facture` (`id`, `id_commande`, `date_facture`, `montant`, `mode_paiement`, `statut_paiement`) VALUES
(1, 1, '2024-12-01 11:00:00', 539.99, 'CB', 'payé'),
(2, 2, '2024-12-05 16:00:00', 1199.97, 'CB', 'payé'),
(3, 3, '2024-12-10 19:00:00', 259.98, 'especes', 'en attente'),
(4, 4, '2024-12-19 09:51:38', 54.99, '', 'en attente'),
(5, 5, '2024-12-19 10:21:50', 514.99, '', 'en attente');

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

CREATE TABLE `livraison` (
  `id` int(11) NOT NULL,
  `id_commande` int(11) NOT NULL,
  `adresse_livraison` text NOT NULL,
  `transporteur` varchar(255) DEFAULT NULL,
  `date_estimee` datetime DEFAULT NULL,
  `statut_livraison` enum('préparée','en transit','livrée','retournée') DEFAULT 'préparée',
  `frais_livraison` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `livraison`
--

INSERT INTO `livraison` (`id`, `id_commande`, `adresse_livraison`, `transporteur`, `date_estimee`, `statut_livraison`, `frais_livraison`) VALUES
(1, 1, '10 Rue de Paris, 75001 Paris', 'La Poste', '2024-12-03 14:00:00', 'livrée', 12.99),
(2, 2, '10 Rue de Paris, 75001 Paris', 'DHL', '2024-12-07 10:00:00', 'livrée', 15.99),
(3, 3, '10 Rue de Paris, 75001 Paris', 'FedEx', '2024-12-12 17:00:00', 'en transit', 9.99),
(4, 4, 'rue 14', 'UPS', '2024-12-26 00:00:00', 'préparée', 15.00),
(5, 5, 'test', 'UPS', '2024-12-26 00:00:00', 'préparée', 15.00);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `prix` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `id_categorie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id`, `nom`, `description`, `prix`, `stock`, `image`, `id_categorie`) VALUES
(1, 'PlayStation 5', 'La PlayStation 5 est la toute dernière console de jeux de Sony, offrant une expérience de jeu sans précédent grâce à sa puissance de traitement, son SSD ultra-rapide et ses graphismes en 4K. Profitez de jeux immersifs avec des temps de chargement réduits, un son 3D et une manette DualSense révolutionnaire avec des retours haptiques et des gâchettes adaptatives.', 499.99, 50, 'https://images.unsplash.com/photo-1731405832370-f7a9bf0f2bba?q=80&w=1932&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 1),
(2, 'Xbox Series X', 'La Xbox Series X est la console la plus puissante de Microsoft, équipée d\'un processeur AMD Ryzen customisé, d\'une carte graphique RDNA 2, et d\'un SSD ultra-rapide. Profitez de performances exceptionnelles, de temps de chargement rapides, et d\'une résolution 4K à 120 Hz, avec une compatibilité totale avec les jeux Xbox One et des jeux optimisés pour la Series X.', 499.99, 29, 'https://images.unsplash.com/photo-1612801799890-4ba4760b6590?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 1),
(3, 'Nintendo Switch', 'La Nintendo Switch est une console hybride qui peut être utilisée à la fois comme une console de salon ou une console portable. Grâce à son écran tactile et sa possibilité de se transformer en mode portable, la Switch est idéale pour jouer à des jeux populaires comme \"The Legend of Zelda: Breath of the Wild\" et \"Super Mario Odyssey\" tout en voyageant.', 299.99, 70, 'https://images.unsplash.com/photo-1612036781124-847f8939b154?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 1),
(4, 'The Last of Us Part II', 'The Last of Us Part II est un jeu d\'aventure et d\'action acclamé par la critique, se déroulant dans un monde post-apocalyptique. Vous incarnez Ellie, une jeune femme déterminée à venger la mort de son père adoptif. Ce jeu est connu pour ses graphismes incroyables, son histoire poignante, et ses mécanismes de gameplay immersifs qui vous feront vivre une expérience émotionnellement intense.', 39.99, 99, 'https://cdn.hmv.com/r/w-640/hmv/files/2b/2b386e34-dc1e-4cd9-a04b-40f76327ef69.jpg', 2),
(5, 'Cyberpunk 2077', 'Cyberpunk 2077 est un jeu de rôle futuriste se déroulant dans une ville dystopique en 2077. Vous incarnez V, un mercenaire cherchant à se faire une place dans un monde où les technologies avancées et la cybernétique modifient l\'humain. Le jeu offre un vaste monde ouvert avec des possibilités de personnalisation de personnages, des quêtes fascinantes, et une histoire riche et complexe.', 59.99, 80, 'https://static1.srcdn.com/wordpress/wp-content/uploads/2024/09/the-cyberpunk-board-game-cover-which-features-v-pointing-a-gun-in-front-of-a-car-over-a-yellow-background-superimposed-on-a-smoggy-vista-of-night-city.jpg', 2),
(6, 'Call of Duty: Modern Warfare', 'Call of Duty: Modern Warfare propose une campagne intense et un mode multijoueur ultra-rapide. Explorez des missions de guerre modernes dans des environnements réalistes, affrontez des ennemis intelligents et mettez vos compétences à l\'épreuve dans des combats multijoueurs avec des armes personnalisables et une grande variété de modes de jeu.', 49.99, 120, 'https://media.gettyimages.com/id/186952375/fr/photo/north-las-vegas-nv-copies-of-call-of-duty-ghosts-are-displayed-during-a-launch-event-for-the.jpg?s=2048x2048&w=gi&k=20&c=4ejflMakY1anac9fSUcm3HYhVkDcGDWj0PsNTW3HL2k=', 2),
(7, 'Casque Gaming HyperX', 'Le casque HyperX Gaming est conçu pour offrir une qualité audio immersive grâce à ses haut-parleurs 53mm, ainsi qu\'une réduction des bruits ambiants avec un confort optimal. L\'arceau et les oreillettes en mousse à mémoire de forme offrent un confort maximal pour des sessions de jeu prolongées. Il est équipé d\'un micro amovible avec suppression du bruit pour des communications claires.', 89.99, 200, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0O-6PFQ073txwrIhhJFEbgLKp8bY9_C-WAA&s', 3),
(8, 'Clavier Gaming Logitech', 'Le clavier mécanique RGB Logitech G Pro X est parfait pour les joueurs professionnels grâce à ses switches interchangeables, son éclairage RGB personnalisable, et son design compact. Il offre une réponse rapide et précise, et est conçu pour durer avec un cadre en aluminium et des touches résistantes. Parfait pour les jeux à haute intensité et les compétitions.', 129.99, 150, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXXy28pxOHvkkTadtSpIitL0uwRp--mmEeUQ&s', 3),
(9, 'Razer DeathAdder V2', 'La Razer DeathAdder V2 est une souris gaming haute performance avec un capteur optique ultra-précis de 20 000 DPI. Son design ergonomique et ses boutons programmables permettent un contrôle total dans les jeux compétitifs. Grâce à sa forme iconique et son éclairage RGB, la DeathAdder V2 combine confort, précision et style pour les joueurs.', 69.99, 300, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCJasGhVBBz24jzvD0fYpRISEHGaaFsHPI4w&s', 3),
(10, 'PC Gamer Alienware', 'Le PC Gamer Alienware est une machine de gaming haut de gamme avec un processeur Intel Core i9, une carte graphique NVIDIA RTX 3080 et 32 Go de RAM, capable de faire tourner les jeux les plus exigeants en 4K avec des fréquences d\'images ultra-élevées. Conçu pour les joueurs passionnés, ce PC offre une performance et une expérience de jeu inégalées, ainsi qu\'un design futuriste unique.', 1599.99, 20, 'https://i.dell.com/is/image/DellContent/content/dam/ss2/page-specific/dell-homepage/apj/modules/cs2404g0018-700634-gl-cs-co-aw-m16-site-banner-hp-feature-card-desktop-1440x1080.jpg?fmt=png-alpha&wid=1440&hei=1080', 4),
(11, 'Carte Graphique NVIDIA RTX 3080', 'La carte graphique NVIDIA RTX 3080 est l\'une des meilleures solutions pour les joueurs à la recherche de performances exceptionnelles. Avec 10 Go de mémoire GDDR6X et la technologie Ray Tracing, elle permet de jouer à des jeux en ultra-haute définition avec des graphismes époustouflants. Idéale pour les jeux en 4K et les applications de création de contenu.', 799.99, 40, 'https://www.nvidia.com/content/dam/en-zz/Solutions/geforce/ampere/rtx-3080/geforce-rtx-3080-shop-600-p@2x.png', 4),
(12, 'Processeur Intel i9', 'Le processeur Intel Core i9 est l\'un des meilleurs processeurs disponibles pour les PC gaming et les stations de travail. Avec jusqu\'à 10 cœurs et 20 threads, il offre une performance exceptionnelle pour le multitâche, le rendu graphique, et les jeux en haute résolution. Il est parfait pour les joueurs exigeants qui cherchent des performances maximales dans les titres les plus récents.', 499.99, 60, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-zbk2ztVpGtONyD7DI8b4CF2yjT2r8dB61g&s', 4);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `adresse` text DEFAULT NULL,
  `téléphone` varchar(15) DEFAULT NULL,
  `rôle` enum('client','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `email`, `mot_de_passe`, `adresse`, `téléphone`, `rôle`) VALUES
(1, 'Hamza Elkhattabi', 'hamza@gmail.com', '$2b$10$ht.SkgYMBU0/h6AGf0SmJuqtWowuPh3ZxwE2/4gYq6tsUJlkocq6W', 'Hay Al Qods', '0620304050', 'client'),
(2, 'Mehdi', 'Mehdi@gmail.com', '$2b$10$2DFLpRlakjYsxQhOFv5w.uXCJsiG3k5H8Rmp9urnJdDkSaJBu/lMq', 'Rue 12', '060000000', 'client');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_ibfk_1` (`id_utilisateur`);

--
-- Index pour la table `detailcommande`
--
ALTER TABLE `detailcommande`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detailcommande_ibfk_1` (`id_commande`),
  ADD KEY `detailcommande_ibfk_2` (`id_produit`);

--
-- Index pour la table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`id`),
  ADD KEY `facture_ibfk_1` (`id_commande`);

--
-- Index pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD PRIMARY KEY (`id`),
  ADD KEY `livraison_ibfk_1` (`id_commande`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `produit_ibfk_1` (`id_categorie`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `detailcommande`
--
ALTER TABLE `detailcommande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `facture`
--
ALTER TABLE `facture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `livraison`
--
ALTER TABLE `livraison`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `detailcommande`
--
ALTER TABLE `detailcommande`
  ADD CONSTRAINT `detailcommande_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detailcommande_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `facture`
--
ALTER TABLE `facture`
  ADD CONSTRAINT `facture_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD CONSTRAINT `livraison_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `produit_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
